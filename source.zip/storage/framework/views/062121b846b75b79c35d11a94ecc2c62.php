

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Blogs</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Search Form -->
    <form method="GET" action="<?php echo e(route('blogs.search')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" class="form-control" name="search" placeholder="Search by tag name..." value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </div>
        <?php if(request('search')): ?>
            <small>Showing results for: "<?php echo e(request('search')); ?>"</small>
        <?php endif; ?>
    </form>

    <!-- Blogs List -->
    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($blog->name); ?></h5>
                <p class="card-text"><?php echo e($blog->description); ?></p>
                <p><strong>Tags:</strong>
                    <?php $__empty_2 = true; $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <span class="badge bg-primary me-1"><?php echo e($tag->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <span class="text-muted">No tags</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No blogs found<?php echo e(request('search') ? ' for this tag.' : '.'); ?></p>
    <?php endif; ?>

    <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary">Create New Blog</a>
    <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-secondary">Create Tag</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\many_to_many\resources\views/blogs/index.blade.php ENDPATH**/ ?>